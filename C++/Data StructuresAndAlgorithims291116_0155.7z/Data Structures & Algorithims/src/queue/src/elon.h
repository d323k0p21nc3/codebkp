#ifndef ELON_H_INCLUDED
#define ELON_H_INCLUDED

#include "queue.cpp"

#endif // ELON_H_INCLUDED

#ifndef ELON_H_INCLUDED
#define ELON_H_INCLUDED

//void load(string description);
void create_list();
void insert_into_list();
void deletion_from_list();

#endif // ELON_H_INCLUDED

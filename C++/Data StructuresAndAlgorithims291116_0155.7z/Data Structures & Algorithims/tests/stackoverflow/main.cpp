#include <iostream>

using namespace std;

void _search (int _list[]);

int main()
{
    int arr[720][720];
    int arr2[10]={1,5,4};

    cout << sizeof(char) << endl;



    _search(arr2);

    return 0;
}

void _search (int _list[])
{
    for (unsigned int c=0; c<=sizeof(_list); c++){
       cout << c;
        }
    }

